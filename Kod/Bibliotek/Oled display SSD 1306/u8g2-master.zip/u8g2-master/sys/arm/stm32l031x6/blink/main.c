
void SystemInit()
{
}

int main()
{
}
